
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","SingletonAbstract"],["c","SingletonInterface"],["c","SingletonTrait"]];
