
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Util\\Singleton\\SingletonAbstract"],["c","FlorianWolters\\Component\\Util\\Singleton\\SingletonInterface"],["c","FlorianWolters\\Component\\Util\\Singleton\\SingletonTrait"]];
