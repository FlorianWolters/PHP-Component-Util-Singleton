
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Util\\Singleton\\MultitonTrait"],["c","FlorianWolters\\Component\\Util\\Singleton\\ReflectionTrait"],["c","FlorianWolters\\Component\\Util\\Singleton\\SingletonTrait"]];
